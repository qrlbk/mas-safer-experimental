// Local hardening patch. Does not change license generation or activation protocols.
namespace LibTSforge
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    // A batch is explicit: disposing after an exception NEVER saves pending data.
    // File.Replace is atomic per file, not across files or across power loss.
    public sealed class StoreWriteBatch : IDisposable
    {
        [ThreadStatic] private static StoreWriteBatch active;
        private readonly List<string> paths = new List<string>();
        private readonly List<byte[]> contents = new List<byte[]>();
        private bool finished;

        public StoreWriteBatch()
        {
            if (active != null) throw new InvalidOperationException("Nested store write batch.");
            active = this;
        }

        private static void CheckPath(string path)
        {
            for (string p = Path.GetFullPath(path); !string.IsNullOrEmpty(p); p = Path.GetDirectoryName(p))
            {
                if ((File.GetAttributes(p) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Refusing a redirected store path: " + p);
            }
        }

        public static void Write(FileStream[] files, byte[][] data)
        {
            if (files.Length != data.Length || files.Length == 0) throw new ArgumentException("Invalid write set.");
            string[] names = files.Select(f => f.Name).ToArray();
            for (int i = 0; i < names.Length; i++) CheckPath(names[i]);
            // Data has already been serialized/encrypted successfully. Release the locks only now.
            foreach (FileStream file in files) file.Close();
            if (active != null)
            {
                for (int i = 0; i < names.Length; i++)
                {
                    if (active.paths.Contains(names[i])) throw new InvalidOperationException("Duplicate store path.");
                    active.paths.Add(names[i]);
                    active.contents.Add(data[i]);
                }
            }
            else ReplaceAll(names, data);
        }

        public void Commit()
        {
            if (finished || active != this) throw new InvalidOperationException("Inactive store batch.");
            try { ReplaceAll(paths.ToArray(), contents.ToArray()); }
            finally { finished = true; active = null; }
        }

        private static void ReplaceAll(string[] names, byte[][] data)
        {
            string suffix = ".mas-safer-" + Guid.NewGuid().ToString("N");
            string[] temporary = names.Select(n => n + suffix + ".tmp").ToArray();
            string[] backups = names.Select(n => n + suffix + ".bak").ToArray();
            int replaced = 0;
            try
            {
                // Stage every output before touching ANY destination. No truncate/write fallback.
                for (int i = 0; i < names.Length; i++)
                {
                    CheckPath(names[i]);
                    using (FileStream output = new FileStream(temporary[i], FileMode.CreateNew,
                        FileAccess.Write, FileShare.None, 4096, FileOptions.WriteThrough))
                    {
                        output.Write(data[i], 0, data[i].Length);
                        output.Flush();
                    }
                    if (!File.ReadAllBytes(temporary[i]).SequenceEqual(data[i]))
                        throw new IOException("Staged store verification failed.");
                }
                for (int i = 0; i < names.Length; i++)
                {
                    CheckPath(names[i]);
                    File.Replace(temporary[i], names[i], backups[i]);
                    replaced++;
                }
            }
            catch (Exception writeError)
            {
                string rollbackErrors = "";
                for (int i = replaced - 1; i >= 0; i--)
                {
                    string restore = names[i] + suffix + ".restore";
                    try
                    {
                        CheckPath(names[i]);
                        File.Copy(backups[i], restore, false);
                        File.Replace(restore, names[i], null);
                    }
                    catch (Exception ex) { rollbackErrors += " " + names[i] + ": " + ex.Message; }
                }
                throw new IOException("Store write failed. Backups retained with suffix " + suffix +
                    (rollbackErrors.Length == 0 ? ". Completed replacements rolled back." :
                    ". MANUAL RECOVERY REQUIRED:" + rollbackErrors), writeError);
            }
            finally
            {
                foreach (string path in temporary)
                {
                    try { if (File.Exists(path)) File.Delete(path); }
                    catch { /* Keep staging file rather than hiding the primary error. */ }
                }
            }
        }

        public void Dispose()
        {
            if (active == this) active = null;
            finished = true;
            paths.Clear();
            contents.Clear();
        }
    }
}
